#include<windows.h>
#include<bits/stdc++.h>
#include <GL/glut.h>
#include <cmath>
#include <iostream>
#include <sstream>
#include <vector>

static int slices = 16;
static int stacks = 16;
int colorChanger = 0;
GLuint colorCounter = 0;


static void resize(int width, int height)
{
    const float area = (float) width / (float) height;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-area, area, -1.0, 1.0, 2.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity() ;
}

static void display(void)
{
    const double t = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
    const double a = t*90.0;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPushMatrix();
        glTranslated(0,0,-6);
        glRotated(60,1,0,0);

    // This GLUT method draws a teapot.  You should replace
// it with code which draws the object you loaded.
glutSolidCube(1);

    glPopMatrix();

    //Color for the object
    GLfloat diffColors[6][4] = {{0.5, 0.5, 0.9, 1.0},
                                 {0.9, 0.5, 0.5, 1.0},
                                 {0.5, 0.9, 0.3, 1.0},
                                 {0.9, 0.7, 0.2, 1.0},
                                 {0.3, 0.8, 0.9, 1.0},
                                 {1.0, 0.0, 0.0, 1.0}};

     GLfloat diffColors2[45][4] = {

                                 {0, 0, 0.2, 1.0},
                                 {0, 0, 0.3, 1.0},
                                 {0, 0, 0.4, 1.0},
                                 {0, 0, 0.5, 1.0},
                                 {0, 0, 0.6, 1.0},
                                 {0, 0, 0.7, 1.0},
                                 {0, 0, 0.8, 1.0},
                                 {0, 0, 0.9, 1.0},
                                 {0, 0, 1, 1.0},


                                 {0.1, 0, 0, 1.0},
                                 {0.2, 0, 0, 1.0},
                                 {0.3, 0, 0, 1.0},
                                 {0.4, 0, 0, 1.0},
                                 {0.5, 0, 0, 1.0},
                                 {0.6, 0, 0, 1.0},
                                 {0.7, 0, 0, 1.0},
                                 {0.8, 0, 0, 1.0},
                                 {0.9, 0, 0, 1.0},

                                 {0, 0.2, 0, 1.0},
                                 {0, 0.3, 0, 1.0},
                                 {0, 0.4, 0, 1.0},
                                 {0, 0.5, 0, 1.0},
                                 {0, 0.6, 0, 1.0},
                                 {0, 0.7, 0, 1.0},
                                 {0, 0.8, 0, 1.0},
                                 {0, 0.9, 0, 1.0},
                                 {0, 1, 0, 1.0},

                                 {0.9, 0.1, 0, 1.0},
                                 {0.8, 0.1, 0, 1.0},
                                 {0.7, 0.1, 0, 1.0},
                                 {0.6, 0.1, 0, 1.0},
                                 {0.5, 0.1, 0, 1.0},
                                 {0.4, 0.1, 0, 1.0},
                                 {0.3, 0.1, 0, 1.0},
                                 {0.2, 0.1, 0, 1.0},
                                 {0.1, 0.1, 0, 1.0},

                                 {0, 0.9, 0.1, 1.0},
                                 {0, 0.8, 0.1, 1.0},
                                 {0, 0.7, 0.1, 1.0},
                                 {0, 0.6, 0.1, 1.0},
                                 {0, 0.5, 0.1, 1.0},
                                 {0, 0.4, 0.1, 1.0},
                                 {0, 0.3, 0.1, 1.0},
                                 {0, 0.2, 0.1, 1.0},
                                 {0, 0.1, 0.1, 1.0}};

    if(colorChanger ==1) //If auto color transition enabled
    {
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, diffColors2[colorCounter]);
    }

    else
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, diffColors[colorCounter]);

// Define specular color and shininess
    GLfloat specColor[] = {1.0, 1.0, 1.0, 1.0};
    GLfloat shininess[] = {100.0};

// Note that the specular color and shininess can stay constant
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specColor);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, shininess);

    // Set light properties
    // Light color (RGBA)
    GLfloat Lt0diff[] = {1.0,1.0,1.0,1.0};

    /*
    // Light position
    GLfloat Lt0pos[] = {1.0f, 1.0f, 5.0f, 1.0f};

    glLightfv(GL_LIGHT0, GL_DIFFUSE, Lt0diff);
    glLightfv(GL_LIGHT0, GL_POSITION, Lt0pos);

    */

    // Dump the image to the screen.
    glutSwapBuffers();
}


static void key(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 'c': //Color toggle
            colorChanger = 0;
            colorCounter += 1;
            if(colorCounter>5)
                colorCounter=0;
            break;

        case 't': //Enable/Disable smooth color transition

            colorChanger = 1;
            colorCounter += 1;
            if(colorCounter>44)
                colorCounter=0;
            break;

            default:
            printf("Unhandled key press %c\n",key);

    }

    glutPostRedisplay();
}



static void idle(void)
{
    glutPostRedisplay();
}

/*
void loadInput()
{
// load the OBJ file here
}

*/


// Main routine.
// Set up OpenGL, define the callbacks and start the main loop
int main(int argc, char *argv[])
{
    glutInit(&argc, argv);

    // We're going to animate it, so double buffer
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    // Initial parameters for window position and size
    glutInitWindowPosition(180,180);
    glutInitWindowSize(1200,700);
    glutCreateWindow("Assignment_18101025");

    // Initialize OpenGL parameters.
    //initRendering();

    // Set up the callback function for resizing windows
    glutReshapeFunc(resize);
    // Call this whenever window needs redrawing
    glutDisplayFunc(display);

    // Set up callback functions for key presses
    glutKeyboardFunc(key);
    glutIdleFunc(idle);

    //glClearColor(1,1,1,1);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);

     // Start the main loop.  glutMainLoop never returns.
    glutMainLoop();

    return 0;
}
